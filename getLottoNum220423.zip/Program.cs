﻿namespace getLottoNum220423
{
	class Program
	{
		
		static void Main(string[] args)
		{
			MainLogic logic = new MainLogic();
			
			logic.LogicPlayer();
			//logic.EndFunc();
		}

	}
}
