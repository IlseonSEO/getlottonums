﻿using System;
using System.Collections.Generic;
using System.Text;

namespace getLottoNum220423
{
	public class Numbers
	{
		enum EPRIZE
		{ 
			NONE,
			FIRST,
			SECOND,
			THIRD,
			FOURTH,
			FIFTH,
		}

		private List<int> list = new List<int>();
		private int bonus = 0;
		private int seed =0;
		private EPRIZE prize = EPRIZE.NONE;
		public Numbers()
		{ }
		public Numbers(int[] _arr)
		{
			SetNumbers(_arr);
		}

		public Numbers(string[] _arr)
		{
			list.Clear();

			for (int i=0; i<_arr.Length;++i)
			{
				var num = -1;
				if (int.TryParse(_arr[i], out num))
				{
					if (list.Count == 6)
						SetBonus(num);
					else
						list.Add(num);
				}	
				else
				{
					Console.WriteLine(string.Format("잘못된문자 {0}",num));
					list.Clear();
					break;
				}
			}

			var bonusNum = _arr.Length - 1;
			int.TryParse(_arr[bonusNum], out bonus);
		}

		public Numbers(bool isCreate)
		{
			if (isCreate)
				CreateNumbers();
		}

		public Numbers(int seed)
		{
			SetSeed(seed);
			CreateNumbersByTimeSeed();
		}

		public void SetSeed(int _seed)
		{
			seed = _seed;
		}

		public void SetBonus(int _bonus)
		{
			bonus = _bonus;
		}

		public void CreateNumbers()
		{
			list.Clear();
			Random ran = new Random();

			while(list.Count < 6)
			{
				var ranValue = ran.Next(1, 46);
				if (list.Contains(ranValue) == false)
					list.Add(ranValue);
			}

			list.Sort();
		}

		public void CreateNumbersByTimeSeed()
		{
			list.Clear();

			Random ran = new Random(seed);
			while (list.Count < 6)
			{
				//var seedProp = seed + (list.Count * 5);
				var ranValue = ran.Next(1, 46);
				if (list.Contains(ranValue) == false)
					list.Add(ranValue);
			}

			list.Sort();
		}

		public void SetNumbers(int[] _arr)
		{
			list.Clear();
			for (int i = 0; i < _arr.Length; ++i)
			{
				list.Add(_arr[i]);
			}
		}

		public int[] GetNumbers()
		{
			return list.ToArray();
		}

		public bool IsValid()
		{
			bool isSame = IsDuplicate(0);

			if (isSame || list.Count != 6 || bonus == 0)
				return false;
			
			return true;
		}

		private bool IsDuplicate(int curr)
		{
			if (curr + 1 == list.Count)
				return false;

			for (int i = curr + 1; i < list.Count; ++i)
			{
				if (list[i] == list[curr])
					return true;
			}

			++curr;
			return IsDuplicate(curr);

		}

		public bool IsSame(Numbers _a, bool CheckBonus=false)
		{
			var arr = _a.GetNumbers();
			var sameCnt = 0;

			for (int i = 0; i < arr.Length; ++i)
			{
				for (int curr = 0; curr < list.Count; ++curr)
				{
					if (arr[i] == list[curr])
						++sameCnt;
				}
			}

			if (CheckBonus)
			{
				if (sameCnt == 6 && _a.IsSameBonus(bonus))
					return true;
			}
			else
			{
				if (sameCnt == 6)
					return true;
			}
			
			return false;
		}

		public void PrintNums()
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < list.Count; ++i)
				sb.Append(list[i]+" ");

			Console.WriteLine(sb);
		}

		public string GetStringFormatValue(bool isExistBonus = false)
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < list.Count; ++i)
			{
				sb.Append(list[i]);
				if (isExistBonus)
				{
					if (i < list.Count)
						sb.Append(',');
				}
				else
					if (i < list.Count-1)
					sb.Append(',');
			}

			if (isExistBonus)
				sb.Append(bonus);

			return sb.ToString();
		}

		public bool IsSameBonus(int _bonus)
		{
			if (bonus == _bonus)
				return true;
			return false;
		}

		public string GetCheckLottoNum(Numbers nums)
		{
			var sameCnt = 0;
			List<int> sameList = new List<int>();

			for (int i = 0; i < nums.list.Count; ++i)
			{
				if (list.Contains(nums.list[i]))
				{
					++sameCnt;
					sameList.Add(nums.list[i]);
				}	
			}

			var isSameBonus = nums.IsSameBonus(bonus);

			prize = GetPRIZE(sameCnt, isSameBonus);
			return PrintResult(sameList, sameCnt, prize);
		}

		private string PrintResult(List<int> sameList, int sameCnt, EPRIZE result)
		{
			StringBuilder sb = new StringBuilder();

			for (int i = 0; i < sameList.Count; ++i)
			{
				sb.Append(sameList[i]);
				if(i != sameList.Count -1)
					sb.Append(",");
			}

			var stringResult = string.Empty;
			switch (result)
			{
				case EPRIZE.FIRST:
				case EPRIZE.SECOND:
				case EPRIZE.THIRD:
				case EPRIZE.FOURTH:
				case EPRIZE.FIFTH:
					{
						stringResult = string.Format("{0}등, 맞은 갯수 {1} 맞은 번호 {2}",
										(int)result, sameCnt, sb.ToString());
						break;
					}
				default:
					{
						//stringResult = string.Format("낙첨ㅠ 맞은 갯수 {0} 맞은 번호 {1}",
						//				sameCnt, sb.ToString());
						break;
					}


			}

			return stringResult;
		}

		public bool HasPrize()
		{
			if (prize == EPRIZE.NONE)
				return false;
			return true;
		}

		public ConsoleColor GetPrizeColor()
		{
			switch (prize)
			{
				case EPRIZE.FIRST:
					return ConsoleColor.Yellow;
				case EPRIZE.SECOND:
					return ConsoleColor.Yellow;
				case EPRIZE.THIRD:
					return ConsoleColor.Red;
				case EPRIZE.FOURTH:
					return ConsoleColor.Red;
				case EPRIZE.FIFTH:
					return ConsoleColor.Red;
				default:
					return ConsoleColor.White;
			}
		}


		private EPRIZE GetPRIZE(int sameCnt, bool isSameBonus)
		{
			if (sameCnt == 3 && isSameBonus == false)
				return EPRIZE.FIFTH;
			else if (sameCnt == 4 && isSameBonus == false)
				return EPRIZE.FOURTH;
			else if (sameCnt == 5 && isSameBonus == false)
				return EPRIZE.THIRD;
			else if (sameCnt == 5 && isSameBonus == true)
				return EPRIZE.SECOND;
			else if (sameCnt == 6 && isSameBonus == false)
				return EPRIZE.FIRST;
			else
				return EPRIZE.NONE;
		}

	}
}
