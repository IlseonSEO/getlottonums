﻿using System;
using System.Collections.Generic;

namespace getLottoNum220423
{
	class MainLogic
	{
		private List<Numbers> pastList = new List<Numbers>();
		private List<Numbers> futureList = new List<Numbers>();
		private List<Numbers> myList = new List<Numbers>();
		private FileController file = new FileController();

		public void LogicPlayer()
		{
			file.InitPath();

			//GetNumberAndSaveFile();
			//EndFunc();

			//CheckThisWeekNumber();

			PrintMainMenu();
			GetMainMenuChooseNum();
		}

		private void LoadPastNumbers()
		{
			pastList.Clear();
			var datas = file.LoadFile(FileController.EPATH.PASTDATA);

			for (int i = 0; i< datas.Length; ++i)
			{
				var aData = datas[i].Split(',');
				Numbers num = new Numbers(aData);
				pastList.Add(num);
			}
		}

		private void LoadMyList()
		{
			myList.Clear();
			var datas = file.LoadFile(FileController.EPATH.MYLISTDATA);

			for (int i = 0; i < datas.Length - 1; ++i)
			{
				var aData = datas[i].Split(',');
				Numbers num = new Numbers(aData);
				myList.Add(num);
			}
		}

		// 번호 추출기
		private void GetNumberAndSaveFile()
		{
			LoadPastNumbers();

			// 추첨시간인 20시 38분의 시간 시드 ( 초 ) ==  74333
			// 기본 9초 빼야함.
			// 1 - 38분 53초
			// 2 - 38분 58초
			// 3 - 39분 3초
			// 4 - 39분 9초
			// 5 - 39분 14초
			// 6 - 39분 19초

			futureList.Clear();
			while (futureList.Count < 100)
			{
				Numbers num = new Numbers(true);
				//Numbers num = new Numbers(74333);
				var pastIdx = pastList.FindIndex(x => x.IsSame(num));
				var futureIdx = futureList.FindIndex(x => x.IsSame(num));
				if (pastIdx < 0 && futureIdx < 0)
				{
					futureList.Add(num);
				}
			}

			file.WriteTextFile(futureList, FileController.EPATH.NEWDATA,false);
		}

		private void PrintMainMenu()
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.WriteLine(string.Format("\n"));
			Console.WriteLine(string.Format("원하는 메뉴선택"), Console.ForegroundColor);
			Console.WriteLine(string.Format("1. 번호추출(100개)"));
			Console.WriteLine(string.Format("2. 이번주 번호비교"));
			Console.WriteLine(string.Format("x. 종료"));
		}

		// 번호 확인하기.
		private void CheckThisWeekNumber()
		{
			Console.Clear();
			LoadMyList();

			var input = GetNumberFromInput();
			var numArr = input.Split(',');
			Numbers thisNum = new Numbers(numArr);
			while (thisNum.IsValid() == false)
			{
				input = GetNumberFromInput();
				numArr = input.Split(',');
				thisNum = new Numbers(numArr);
			}

			for (int i = 0; i < myList.Count; ++i)
			{
				var result = myList[i].GetCheckLottoNum(thisNum);
				if (myList[i].HasPrize())
				{
					Console.ForegroundColor = myList[i].GetPrizeColor();
					Console.WriteLine(string.Format("{0}번 {1}", i, result), Console.ForegroundColor);
				}
			}

			if (IsExistPastList(thisNum) == false)
				GetInputSaveThisNum(thisNum);
			else
			{
				string anyInput = string.Empty;
				Console.WriteLine("\n엔터키를 누르면 메뉴로 돌아갑니다.");
				while (string.IsNullOrEmpty(anyInput))
				{
					anyInput = Console.ReadLine();
				}
				LogicPlayer();
			}
			

		}

		private bool IsExistPastList(Numbers num)
		{
			LoadPastNumbers();

			var SameNum = pastList.Find(x => x.IsSame(num, true));

			if (SameNum != null)
				return true;

			return false;
		}

		private void GetInputSaveThisNum(Numbers thisNum)
		{
			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.WriteLine(string.Format("이 번호가 과거 리스트에 없습니다. 저장하시겠습니까? Y or N"), Console.ForegroundColor);
			
			string input = string.Empty;
			while (string.IsNullOrEmpty(input))
			{
				input = Console.ReadLine();
				if (input.Equals("Y") || input.Equals("y"))
				{
					AddthisNumToPastList(thisNum);
				}
				else
				{
					break;
				}
			}
			LogicPlayer();
		}

		private void GetMainMenuChooseNum()
		{
			string input = string.Empty;
			while (string.IsNullOrEmpty(input))
			{ 
				input = Console.ReadLine();
				if (input.Equals("1"))
				{
					GetNumberAndSaveFile();
					EndFunc();
					input = string.Empty;
				}
				else if (input.Equals("2"))
					CheckThisWeekNumber();
				else if (input.Equals("x") || input.Equals("X"))
				{
					Console.ForegroundColor = ConsoleColor.Yellow;
					Console.WriteLine("아무키나 누르면 종료됩니다.", Console.ForegroundColor);
					Console.ReadLine();
					break;
				}
				else
				{
					PrintMainMenu();
					input = string.Empty;
				}
			}
		}

		// 이번주 번호입력.
		private string GetNumberFromInput()
		{
			Console.ForegroundColor = ConsoleColor.Yellow;
			Console.WriteLine(string.Format("다음과 같은 형태 입력 (보너스번호포함) 1,2,3,4,5,6,7"), Console.ForegroundColor);
			string input = Console.ReadLine();
			
			return input;
		}

		private void AddthisNumToPastList(Numbers thisNum)
		{
			LoadPastNumbers();
			pastList.Add(thisNum);
			System.Action act = () =>
			{
				Console.ForegroundColor = ConsoleColor.Yellow;
				Console.WriteLine("saved complete", Console.ForegroundColor);
				Console.WriteLine("아무키나 누르면 종료됩니다.", Console.ForegroundColor);
			};
			file.WriteTextFile(pastList, FileController.EPATH.PASTDATA,true, act);
		}

		private bool IsDuplicateNums(int curr)
		{
			if (curr+1 == pastList.Count)
				return false;

			for (int i = curr + 1; i < pastList.Count; ++i)
			{
				if (pastList[i].IsSame(pastList[curr]))
				{
					pastList[i].PrintNums();
					pastList[curr].PrintNums();
					return true;
				}	
			}
			++curr;
			return IsDuplicateNums(curr);
		}

		public void EndFunc()
		{
			Console.WriteLine(string.Format("Done"));
			file.OpenFoler();
			Console.WriteLine(string.Format("아무키나 누르면 메인메뉴로 돌아갑니다."));
			LogicPlayer();
		}
	}
}
