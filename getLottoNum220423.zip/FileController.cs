﻿using System.IO;
using System.Collections.Generic;

namespace getLottoNum220423
{
	class FileController
	{
		public enum EPATH
		{ 
			PASTDATA,
			MYLISTDATA,
			NEWDATA,
		}

		private string pastPath = @"\datas\lottoPastData.txt";
		private string futurePath = @"\datas\futureList.txt";
		private string myListPath = @"\datas\mylist.txt";

		string projectDirectory;

		public void InitPath()
		{
			string workingDirectory = System.Environment.CurrentDirectory;
			projectDirectory = Directory.GetParent(workingDirectory).Parent.FullName;
		}

		public string[] LoadFile(EPATH type)
		{
			var path = GetPath(type);

			var allString = File.ReadAllText(path);

			var allLine = allString.Split('\n');

			return allLine;

		}

		public void WriteTextFile(List<Numbers> list, EPATH type, bool isExistBonus, System.Action act=null)
		{
			string[] strArr = new string[list.Count];
			for (int i = 0;i< list.Count ; ++i)
			{
				strArr[i] = list[i].GetStringFormatValue(isExistBonus);
			}

			var path = GetPath(type);

			File.WriteAllLines(path, strArr);

			if (act != null)
				act();
		}

		private string GetPath(EPATH type)
		{
			if (type == EPATH.PASTDATA)
				return projectDirectory+pastPath;
			else if (type == EPATH.NEWDATA)
				return projectDirectory+futurePath;
			else
				return projectDirectory+myListPath;
		}

		public void OpenFoler()
		{
			System.Diagnostics.Process.Start(projectDirectory+@"\datas");
		}
	}
}
